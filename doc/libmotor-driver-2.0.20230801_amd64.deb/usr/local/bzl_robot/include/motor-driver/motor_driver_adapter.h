/***************************************************************
 *@Copyright (C), 2019, Bright Dream Robotics co.,Ltd.
 *@filename: 		motor_driver_adapter.h
 *@author: 		  cx
 *@date: 		  2019/7/28 15:33
 *@brief:	motor_driver_adaptable_layar_header
 *@version: 				v1.0.0
 ****************************************************************/
#ifndef __MOTOR_DRIVER_ADAPTER_H__
#define __MOTOR_DRIVER_ADAPTER_H__

#include <iostream>
#include <map>
#include <stdint.h>
#include <stdio.h>
#include <vector>

#define MAX_CAN_NODE_ID 20
#define MAX_CAN_NODE_NUM 20
#define ANGLE_UNIT_SCALE 100
#define SPEED_UNIT_SCALE 100

/*电机相关错误码值*/
#define MOTOR_LICENSE_ERROR 1700    //电机license校验错误
#define MOTOR_DB_ERROR 1701         //电机数据库读取失败
#define CAN_DRIVER_ERROR 1702       //电机can设备打开失败
#define CAN_BUS_ERROR 1703          //电机can总线故障
#define MOTOR_ERROR 1704            //电机错误故障
#define MOTOR_TYPE_UNSUPPORT 1705   //电机类型不适配
#define MOTOR_INIT_FAIL 1706        //电机初始化失败
#define MOTOR_CLEAR_ERROR_FAIL 1707 //电机清除故障失败
#define MOTOR_RESET_FAIL 1708       //电机复位失败
#define MOTOR_NODE_ID_ERROR 1709    //电机ID号错误
#define MOTOR_QUICK_STOP 1710       //电机驱动器急停
#define MOTOR_HOMING_FAIL 1711      //电机回零超时失败
#define MOTOR_ENCODER_LOW_VOLTAGE 1712      //电机编码器存储电池低电压
#define MOTOR_BUS_LOW_VOLTAGE 1713      //电机UVW总线电压过低

#ifndef DBMapTable
typedef std::map<std::string, std::map<std::string, std::string>> DBMapTable;
#endif

typedef enum
{
    MOTOR_TYPE_KINCO = 0,  // KINCO
    MOTOR_TYPE_MOTEC,      // MOTEC
    MOTOR_TYPE_TONGYI,     // TONGYI
    MOTOR_TYPE_SYNTRON_S,  // SYNTRON_S
    MOTOR_TYPE_SYNTRON_D,  // SYNTRON_D
    MOTOR_TYPE_RISE,       // RISE
    MOTOR_TYPE_CURTIS,     // CURTIS
    MOTOR_TYPE_VMMORE,     // VMMORE
    MOTOR_TYPE_HINSON_S,   // HINSON_S
    MOTOR_TYPE_HINSON_D,   // HINSON_D
    MOTOR_TYPE_DELTA,      // DELTA
    MOTOR_TYPE_DONGCHANG,  // DONG CHANG
    MOTOR_TYPE_SYNTRON_LS, // SYNTRON LS 系列
    MOTOR_TYPE_JINLING,    // JINLING
    MOTOR_TYPE_HANDEBAO,   // HANDEBAO
    MOTOR_TYPE_LIWEI,      // LIWEI
    MOTOR_TYPE_HUICHUAN,   // HUICHUAN
    MOTOR_TYPE_KE_YA,      // KEYA
    MOTOR_TYPE_TIAN_TAI,   // TIANTAI
    MOTOR_TYPE_LEISAI,     // LEISAI
    MOTOR_TYPE_ZHONGLING,  // ZHONGLING
    MOTOR_TYPE_TECHNOSOFT, // TECHNOSOFT
    MOTOR_TYPE_MAX         // UNKNOW
} MotorType_t;

typedef enum
{
    MOTOR_STU_KEEP = 0,
    MOTOR_STU_SLOW_DOWN,
    MOTOR_STU_STOP,
    MOTOR_STU_RUN,
    MOTOR_STU_RESET,
    MOTOR_STU_HOLD,          //电机抱闸抱紧
    MOTOR_STU_RELEASE,       //电机抱闸松开
    MOTOR_MODE_TQ,           //电机模式力矩
    MOTOR_MODE_SPEED,        //电机模式立即速度/速度
    MOTOR_LOCK_SHAFT,        //电机锁轴
    MOTOR_LOOSE_SHAFT,       //电机松轴
    MOTOR_GO_HOME,           //电机回零
    MOTOR_MAPPING_HAND,      //手推机器建图
    MOTOR_RESTART_NO_HOMING, //电机复位，但不回零
    MOTOR_STU_OTHER
} SetMotorStu_t;

typedef struct
{
    uint8_t motor_type = 0;         // form MotorType_t
    uint8_t node_id = 0;            // node id
    int8_t operation_mode = 0;      // DEC, the datasheet operation_mode
    int16_t ctrl_word = 0;          // HEX ,DO NOT SET THIS
    int32_t target_position = 0;    // inc
    double profile_speed = 0.0;     // rpm
    double profile_acc = 0.0;       // rps/s
    double profile_dec = 0.0;       // rps/s
    double target_speed = 0.0;      // rpm
    int16_t target_torque = 0;      // %
    double cmd_q_max = 0.0;         // Ap
    uint8_t din_mode0 = 0;          // DEC
    uint8_t din_mode1 = 0;          // DEC
    uint8_t encoder_data_reset = 0; // DEC
    double max_speed = 0.0;         // DEC
    uint8_t home_trigger = 0;       // DEC
    double reduction_ratio = 0.0;   // DEC
    uint8_t install_direction = 0;  // 0 for positive, 1 for negative
    uint32_t encoder_dpi = 0;       // DEC
    uint8_t position_angle = 0;     // 0 for pisition , 1 for angle
    double max_current = 0.0;       // DEC
    int32_t home_offset = 0;        // DEC,home offset
    uint8_t group = 0;              // set group for sync send and recv,default 1
    uint8_t en_profile_speed = 0;   // if set, speed in rostopic mean profile_speed, only in position mode
    uint32_t beat_counts = 0;       // can heart beat num
    int16_t oper_mode_flag = 0;     // 0 -- no change, 1 -- pp line, 2-- pp rotate, 3 -- pv, -3 -- piv;
                                    // recode the lastest operation mode
    uint8_t holding_brake = 0;      // 0 -- 不开启抱闸, 1 -- 开启抱闸
    double fix_moving_acc = 0.0;    //定距离移动加速度
    double fix_moving_dec = 0.0;    //定距离移动减速度
    double fix_moving_spd = 0.0;    //定距离移动速度
    double fix_whirling_acc = 0.0;  //定距离移动加速度
    double fix_whirling_dec = 0.0;  //定距离移动减速度
    double fix_whirling_spd = 0.0;  //定距离移动速度
    int32_t err_code = 0;           //电机的故障码
    int8_t origin_mode = 0;         //原点模式
    int32_t origin_turn_spd = 0;    //原点转折信号速度
    int32_t origin_signal_spd = 0;  //原点信号速度
    int32_t origin_acc = 0;         //原点加速度
                                    // int8_t					power_on_find_origin;	//上电找原点
                                    // int16_t					max_current_at_origin;	//寻找原点最大电流
                                    // int8_t					origin_offset_mode;		//原点偏移模式
                                    // int8_t					origin_index_signal_zone;	//原点索引信号盲区
} CanNodeBaseCtrl;

typedef struct
{
    char author[20] = {'0'};
    int32_t version = 0;
    int32_t print = 0;
    char can_interface[16] = {'0'};
    uint8_t can_node_num = 0;
    CanNodeBaseCtrl node_info[MAX_CAN_NODE_NUM];
} IniFileData_t;

typedef struct
{
    int32_t (*GetSpeedCb)(uint16_t node_id, double speed);                   // rpm
    int32_t (*GetPositionAngleCb)(uint16_t node_id, int32_t position_angle); // pulse, do not use it
    int32_t (*GetPositionCb)(uint16_t node_id, int32_t position);            // pulse
    int32_t (*GetAngleCb)(uint16_t node_id, double angle);                   // angle value , units : °
    int32_t (*GetStaCodeCb)(uint16_t node_id, int32_t sta_code);             // status word
    int32_t (*GetCurrentCb)(uint16_t node_id, double current);               // dian liu
    int16_t (*GetDcBusVoltageCb)(uint16_t node_id, int32_t result);          // get DC bus voltage
    int32_t (*GetGlobalErrorCb)(int32_t result);                 //全局错误码，0 -- 正常， 其他 -- 错误码
    int32_t (*GetErrCodeCb)(uint16_t node_id, int32_t err_code); // error code
    int32_t (*GetControlCode)(uint16_t node_id, int32_t control_code); //电机控制字
    int32_t (*GetWorkState)(uint16_t node_id, int8_t work_state);      //电机工作模式
    int32_t (*GetTargetSpeedCb)(uint16_t node_id, double speed);       //目标速度
    int32_t (*GetOnLineState)(uint16_t node_id,
                              int32_t on_line); //在线状态，on_line: 1 -- 在线， 0 -- 掉线
} MotorCallBackList_t;

typedef struct
{
    int32_t index = 0;        // suo yin
    char type[8] = {'0'};     // zi fu suo yin
    char model[16] = {'0'};   // motor xing hao
    uint8_t name_id = 0;      // dev id
    int32_t state = 0;        // state: 0 - not use, 1 - normal, 2 - checking, 3 - exception
    char message[32] = {'0'}; // detail msg
    int number = 0;
} motorCheckMsg_t;

struct MultiMotorSpeed
{
    std::vector<uint8_t> node; // node 从小到大顺序排列
    std::vector<double> setSpeed;
};

struct MultiMotorAngle
{
    std::vector<uint8_t> node; // node 从小到大顺序排列
    std::vector<double> setAngle;
};

struct MultiMotorPosition
{
    std::vector<uint8_t> node; // node 从小到大顺序排列
    std::vector<uint32_t> setPosition;
};

struct MultiMotorTorque
{
    std::vector<uint8_t> node; // node 从小到大顺序排列
    std::vector<int16_t> setTorque;
};

/******************************************************
 *@brief  Get Index By Node
 *@author cx
 *@date   2019-11-26
 *@param  int node_id  motor id
 *@return extern int  index in CanNodeBaseCtrl node_info
 ******************************************************/
extern int32_t GetIndexByNodeId(uint8_t node_id);

/******************************************************
 *@brief  motor init and motor init, then start
 *@author
 *@date   2022-04-19
 *@param  DBMapTable& agvInfo
 *@param  DBMapTable& motorInfo
 *@param  MotorCallBackList_t * callback_list
 *@return extern int
 ******************************************************/
extern int32_t MotorInit(DBMapTable agvInfo, DBMapTable motorInfo, MotorCallBackList_t* callback_list);

// extern int32_t Init(IniFileData_t& ini_data, MotorCallBackList_t& callback_list);
extern int32_t MotorInit(IniFileData_t* ini_data, MotorCallBackList_t* callback_list);
/******************************************************
 *@brief  motor exit
 *@author cx
 *@date   2019-11-26
 *@param  void
 *@return extern void
 ******************************************************/
extern void MotorExit(void);
/******************************************************
 *@brief  motor lib clean err
 *@author cx
 *@date   2019-11-26
 *@param  int node_id
 *@return extern int
 ******************************************************/
extern int32_t MotorCleanError(uint8_t node_id);
/******************************************************
 *@brief  motor restart
 *@author cx
 *@date   2019-11-26
 *@param  int node_id
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t MotorRestart();
/******************************************************
 *@brief  set motor stu
 *@author cx
 *@date   2019-11-26
 *@param  SetMotorStu_t stu
 *@return extern int
 ******************************************************/
extern int32_t MotorStuSet(SetMotorStu_t stu);
/******************************************************
 *@brief  set motor speed by motor nodeid
 *@author cx
 *@date   2019-11-26
 *@param  uint8_t node_id
 *@param  int speed_rpm
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t BzlSetMotorSpeed(uint8_t node_id, double speed);
/******************************************************
 *@brief  set motor torque by motor nodeid
 *@author cx
 *@date   2019-11-26
 *@param  uint8_t node_id
 *@param  short torque
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t BzlSetMotorTorque(uint8_t node_id, int16_t torque);
/******************************************************
 *@brief  set motor angle by motor nodeid
 *@author cx
 *@date   2019-11-26
 *@param  uint8_t node_id
 *@param  float angle
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t BzlSetMotorAngle(uint8_t node_id, double angle);
/******************************************************
 *@brief  set motor position by motor nodeid
 *@author cx
 *@date   2019-11-26
 *@param  uint8_t node_id
 *@param  int position
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t BzlSetMotorPosition(uint8_t node_id, int32_t position);
/******************************************************
 *@brief  set motor position or angle by motor nodeid
 *@author yww
 *@date   2019-11-26
 *@param  uint8_t node_id
 *@param  int position_angle
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t BzlSetMotorPositionAngle(uint8_t node_id, int32_t position_angle);

/******************************************************
 *@brief  get robot function code
 *@author cx
 *@date   2020-11-18
 *@param  int32_t
 *@return 32bit function_code, bit 0： 0 -- 不支持定距移动, 1 -- 支持定距移动
 *							   bit 1 -- bit 31: 暂无  默认 0
 ******************************************************/
extern int32_t BzlGetRobotFunctionCode();

/******************************************************
 *@brief  set motor fix move or whirl cmd param
 *@author cx
 *@date   2021-04-13
 *@param  int move_whirl: 1 -- move, 2 -- whirl
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern int32_t BzlSetMotorFixMoveWhirl(int move_whirl);

/******************************************************
 *@brief  get motor check msg
 *@param  void
 *@return extern int  0 for access and -1 for fail
 ******************************************************/
extern motorCheckMsg_t* BzlGetMotorCheckMsg();

extern int32_t MotorSetSingleStatus(uint8_t node_id, SetMotorStu_t stu);

extern int32_t BzlPadSetMotorHoming(uint8_t node_id);

// 同时设置多个电机速度
extern int32_t BzlSetMotorMultiSpeed(MultiMotorSpeed multi_speed);

// 同时设置多个电机角度
extern int32_t BzlSetMotorMultiAngle(MultiMotorAngle multi_angle);

// 同时设置多个电机角度
extern int32_t BzlSetMotorMultiPosition(MultiMotorPosition multi_position);

// 同时设置多个电机力矩
extern int32_t BzlSetMotorMultiTorque(MultiMotorTorque multi_torque);

extern int32_t BzlPadOneKeyHoming();
#endif // __MOTOR_DRIVER_ADAPTER_H__
